package com.sesion5.clase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaseApplication.class, args);
	}

}
