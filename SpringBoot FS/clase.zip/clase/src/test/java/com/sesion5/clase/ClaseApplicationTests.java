package com.sesion5.clase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
